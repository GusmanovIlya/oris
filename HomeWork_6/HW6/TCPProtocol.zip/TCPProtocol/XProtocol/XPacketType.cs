﻿namespace XProtocol
{
    public enum XPacketType
    {
        Unknown,
        Handshake,
        Point,
        MapState,
        PlayerList
    }
}
