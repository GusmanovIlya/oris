﻿using XProtocol.Serializator;

namespace XProtocol
{
    public class XPacketPlayerList
    {
        [XField(1)]
        public string SerializedData;
    }
}
